# 16 · 需求—模块—契约—验证追踪表

本表用于设计验收、Issue/PR 评审，完整需求见 `02_SRS.md`；测试编号参见 `12_EVALUATION.md`。

| 需求 | 负责模块/章节 | 契约入口 | 关键验证 |
|---|---|---|---|
| FR-001 | API Auth，04/11 | `openapi.yaml` security | Observer 设备写 403，EVAL-14 |
| FR-002 | Experiment Service，07/09 | `POST /experiments` | 幂等键、重复提交 |
| FR-003 | Planner Agent，05/06 | Agent Manifest + Proposal JSON 示例 | EVAL-01，计划 DAG 校验 |
| FR-004 | Approval Service，04/07 | `POST /experiments/{id}/approvals` | EVAL-12 |
| FR-005 | Agent Registry，05 | `agent_manifest.schema.json` | 配置版本 hash |
| FR-006 | Tool/Skill Registry，05/11 | Schema + Tool Metadata | EVAL-02/EVAL-03 |
| FR-007 | Device Registry，08 | `capability.schema.json`, instruments API | EVAL-14，离线禁写 |
| FR-008 | Scheduler，07 | Command Envelope/Resource Lease | EVAL-06 |
| FR-009 | Gateway/CommandLedger，07/08 | `command.schema.json` | EVAL-04/EVAL-05 |
| FR-010 | ExperimentView，06/09 | Dataset API/ABAC | 跨实验数据拒绝 |
| FR-011 | Data Service，09 | Dataset Manifest | EVAL-10 |
| FR-012 | SSE Service，04/10 | `GET /experiments/{id}/events` | EVAL-07 |
| FR-013 | Run Control，04/07 | `POST /runs/{id}/actions` | EVAL-09 |
| FR-014 | Multi-Agent Coordinator，06 | Proposal/Agent Manifest | EVAL-13 |
| FR-015 | Safety Gateway，08/11 | Command Policy/Fencing | EVAL-02/EVAL-14 |
| FR-016 | Agent Platform，05/06 | Autonomy Envelope | 越界变新提案 |
| FR-017 | Workflow Manager，07 | Plan Revision | EVAL-12 |
| FR-018 | Data Explorer，04/09 | Dataset API | 校验和/元数据导出 |
| FR-019 | Gateway/Deploy，08/13 | Capability + Command | 站点离线演练 |
| FR-020 | Skills Registry，05 | Agent Manifest | 技能版本锁定 |

## 发布审核

1. 所有 MUST 需求均有至少一个通过的自动化或现场测试及存档的结果链接。
2. 所有可影响物理世界的操作，在现场安全清单中有责任人及对应厂商规程。
3. `EVAL-02,03,04,05,06,09,10,11,12,14` 为阻断项；不允许以 Agent 自评“已安全”代替。
4. 文档更改必须更新追踪表；若 OpenAPI/Schema 更新而前端/网关未更新，发布不通过。
