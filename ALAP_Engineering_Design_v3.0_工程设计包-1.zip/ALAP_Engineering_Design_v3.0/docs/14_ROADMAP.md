# 14 · 研发路线、实施顺序与交付验收

## 1. 开发原则

按**端到端垂直切片**交付，而不是先把所有页面做完、再做全部 Agent、最后才考虑 Gateway 安全。每个迭代都包含 UI→API→状态→模拟执行→数据→审计的完整闭环。

## 2. 六个增量里程碑

| 阶段 | 范围 | 可演示交付物 | 质量门禁 |
|---|---|---|---|
| M0 · 契约与模拟 | Repo、OpenAPI/Schema、用户身份 stub、模拟仪器、测试基建 | 能运行的 mock Gateway 与基础合同测试 | Schema/安全用例 |
| M1 · Web 纵向闭环 | Experiment CRUD、Agent Workspace、SSE、基本 Run 视图 | 浏览器发起一个模拟实验并看到全过程 | FR-001/002/012 |
| M2 · Runtime | Agent Definition、LLM 适配、Tool/Skill、Context、Trace | Planner 产出可审核计划卡片 | FR-003/005/006 |
| M3 · 确定性调度 | Plan revision、审批、DAG、租约、CommandLedger、Outbox | 三模拟设备协同，异常 UNKNOWN | FR-004/008/009/013 |
| M4 · 数据与多 Agent | Dataset Store/Manifest、事件协作、分析和再规划 | 数据驱动的下一轮 Proposal，需审批 | FR-010/011/014 |
| M5 · 受控真机试点 | Gateway 适配 1 台低风险设备、现场策略、故障演练 | 在值守下执行有限、可审计操作 | FR-007/015 + G2 |

M0–M4 均不需要真实高风险仪器接入。真正上线前完成 G1/G2 的逐设备风险审查；M5 只代表试点而非可无人值守运行。

## 3. 首批 Issues（含依赖与验收）

| Issue | 任务 | 依赖 | 完成标准 |
|---|---|---|---|
| ENG-001 | Repo、CI、代码规范、契约 lint | 无 | CI 自动检查 OpenAPI/JSON Schema |
| ENG-002 | Gateway Simulator: 温控/磁体/源表 | ENG-001 | 支持延迟、稳定、超时、丢 ACK、恢复 |
| ENG-003 | User Auth + Experiment CRUD | ENG-001 | 401/403/409/幂等正确 |
| ENG-004 | Agent Runtime basic loop | ENG-001 | Tool policy 生效、Trace 完整 |
| ENG-005 | Agent Workspace SSE UI | ENG-003 | 重连补偿/快照重同步 |
| ENG-006 | PlanProposal/Revision/Approval | ENG-003/004 | 审批与版本绑定、变更作废 |
| ENG-007 | DAG Scheduler + Task FSM | ENG-002/006 | 不可非法状态跳转 |
| ENG-008 | Resource Lease + Fencing | ENG-002/007 | 并发与旧 token 测试通过 |
| ENG-009 | CommandLedger + UNKNOWN 对账 | ENG-007/008 | ACK 丢失时不重复副作用 |
| ENG-010 | DataStore + Manifest commit | ENG-002/003 | 哈希/血缘完整，半成品不可见 |
| ENG-011 | NATS/Outbox + event replay | ENG-007/010 | 重投幂等、SSE 补偿 |
| ENG-012 | Instrument/Agent/Approval UI | ENG-005/006/008 | 权限及状态机可视化 |
| ENG-013 | Analysis Agent + next Proposal | ENG-004/010/011 | 基于数据新提案不直达仪器 |
| ENG-014 | 安全故障注入 + 红队场景 | ENG-002/008/009 | 安全阻断项全部通过 |
| ENG-015 | 单台实际设备受控接入 | ENG-014 + 现场评审 | G1/G2 手册/限幅/急停/恢复记录 |

## 4. Definition of Done（每个模块）

1. 需求 ID 与 API/Schema、测试用例存在显式对应。
2. 输入/输出 Schema、数据单位、错误码、权限和日志字段一致。
3. 正常流程 + 至少一种失败流程 + 权限错误经过测试。
4. API 与 UI 对运行、未知、暂停、取消的状态解释一致。
5. 任何设备写的变更均有 Safety Review，不可省略。
6. 文档记录版本、维护者、ADR 及迁移说明。

## 5. “先做 Web 还是先做 Engine？”

建议两条工作流并行：前端先用固定 Fixture 和 mock SSE 做真实交互体验；后端同时完成 Simulator 与 API 契约。随后用一次端到端演示验证接口，而不是开发两套彼此不匹配的静态产品。

## 6. 下一轮评审输出

至少确认 ① 设备资产清单及桥接实际能力 ② 危险操作分级与现场安全责任 ③ M0–M2 的协作分工 ④ Agent 模型接入与数据出域政策 ⑤ 数据存储、网关操作系统和网络连接图。确认后锁定 SRS v3.1 与首期 Issue 迭代计划。
