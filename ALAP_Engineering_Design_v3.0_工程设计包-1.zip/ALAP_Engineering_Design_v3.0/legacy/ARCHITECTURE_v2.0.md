# Autonomous Laboratory Agent Platform（ALAP）
## 分布式多仪器协同智能实验平台——系统总体设计说明书

> **文档版本**：v2.0（总体设计草案）  
> **编制日期**：2026-10-16  
> **状态**：可用于原型设计、技术评审与任务拆分；**不是已验证的仪器安全操作规程**  
> **核心设计**：借鉴 ARTEX 的 Planner–Worker、共享状态、事件驱动和执行溯源思想，构建面向实验室的 Web 化、多 Agent、分布式仪器协同平台。  
> **范围说明**：文中的设备型号、测量参数、接口报文均为设计示例；真实设备的限值、停机方式和命令集必须依据设备手册及实验室规程配置和验证。

---

# 0. 执行摘要与架构决策

本平台并非“聊天机器人 + 仪器命令接口”，而是一套**面向科研实验的多用户 Web 产品和分布式控制系统**。用户可以通过 Web 工作台创建实验、与 Planner 对话、审查任务图、批准高风险操作、观察仪器实时状态、查看数据曲线和追踪 Agent 决策；多台异地仪器可通过本地 Gateway 接入，在统一实验会话下协作运行。

**推荐主架构：分层自治 + 集中仲裁 + 边缘确定性执行。**

- **中央 Planner（LLM）**：理解科研意图、提出任务计划、分析结果和发起后续测量提案。
- **实验编排器 Scheduler（确定性程序）**：执行依赖检查、资源独占、审批、权限、任务状态转换、超时与冲突仲裁；它不依赖 LLM 才能正确工作。
- **Instrument Agent（逻辑代理）**：每台仪器拥有独立能力、工具、状态与权限，可局部分析、建议和执行**已授权**的高级任务。多个代理可共享同一个 LLM 服务。
- **Measurement Agent（实验技能代理）**：封装 IV、R–T、R–H、磁场历史等跨设备实验流程，避免 Planner 编排每个采样点。
- **Gateway / Local Controller（仪器边缘节点）**：部署在仪器所在电脑或近端网络，兼容 TCP、GPIB、USB 及既有桥接程序，执行本地确定性扫描，并直接落实安全策略。
- **共享数据与事件层**：PostgreSQL 存元数据及权威状态，HDF5/Zarr 存科学数据，NATS JetStream 传输可恢复的业务事件；前端通过 SSE/WebSocket 获得实时更新。
- **安全边界**：LLM 不直接发送未经验证的 SCPI；对设备的实际控制需经过授权、资源租约、安全检查和边缘控制器。紧急停机与物理互锁不得依赖 Web 或 LLM。

### 0.1 设计决定（ADR 摘要）

| 编号 | 决定 | 原因 | 初期实施 |
|---|---|---|---|
| ADR-01 | 中央规划，分布式执行 | 全局实验一致性 + 低延迟仪器控制 | 必须 |
| ADR-02 | Agent 与仪器驱动解耦 | 可更换模型/Agent 框架而不影响设备层 | 必须 |
| ADR-03 | 每台设备只有一个有权写入的控制所有者 | 防并发冲突与误操作 | 必须 |
| ADR-04 | 结构化任务，不开放 LLM 任意原始命令 | 可验证、可审计、安全 | 必须 |
| ADR-05 | 任务与事件持久化；设备命令不盲目重试 | 故障恢复与物理幂等性不同 | 必须 |
| ADR-06 | 原始实验数据与消息总线分离 | 大数据吞吐和数据完整性 | 必须 |
| ADR-07 | 优先采用模块化单体 + 独立 Gateway | 降低 MVP 运维复杂度 | 推荐 |
| ADR-08 | 高风险任务人工审批；自治等级可配置 | 渐进式开放自主权 | 必须 |
| ADR-09 | 可视化工作流编辑器分阶段交付 | 首期先跑通执行闭环 | P1 |
| ADR-10 | 双图思想采用关系型表 + 关联边实现 | 先确保可查询、可审计；不急于引入图数据库 | 推荐 |

### 0.2 关键术语

- **Experiment**：一次有唯一 ID 的实验会话，包含目标、样品、任务、仪器、数据、审批、审计。
- **Run**：一次具体执行；同一实验可包含多个 Run（重测、重启、参数组）。
- **Task**：具备依赖、资源与状态机的确定性工作单元。
- **Proposal**：Agent 对实验提出的建议，**不等于已经批准的设备命令**。
- **Lease**：设备控制租约，限定有效期、资源与持有者；还需要**单调增加的 fencing token** 阻止过期持有者操作。
- **Gateway**：仪器近端受控服务，封装现有桥接/驱动，执行本地测量并上报真实状态。
- **Instrument Agent**：逻辑设备代理，不必驻留在设备电脑上，不等于底层驱动。

---

# 1. 项目概述与产品定位

## 1.1 目标用户与核心场景

| 用户 | 典型需求 | 交付体验 |
|---|---|---|
| 研究人员 | 用自然语言制定实验、查看曲线、决定是否重测 | Agent 工作台 + 实验工作台 |
| 实验负责人 | 审核计划和危险操作、维护仪器使用规范 | 审批中心 + 审计记录 |
| 仪器管理员 | 连接、校准、锁定、诊断设备 | 仪器中心 + Gateway 管理 |
| 数据分析人员 | 检索数据、溯源与复现算法 | 数据探索器 + 导出 |
| 系统管理员 | 管理角色、模型、服务、备份、告警 | 系统控制台 |

**示例科研场景**：温控器稳定在设定温度后，磁体执行获批的磁场历史序列；源表在规定的零外加场状态下进行 IV 测量；分析代理计算正负临界电流和整流效率；Planner 根据异常点提出加密采样计划，由实验人员/策略引擎决定是否继续。

## 1.2 功能目标（F）

- **F-01 Web 产品**：登录、项目导航、实验与设备总览、实时状态、通知和审批。
- **F-02 Agent 工作区**：自然语言入口、工具调用轨迹、计划图、审批卡片、运行记录。
- **F-03 实验 Studio**：自然语言规划和结构化实验表单、任务 DAG、模板及执行控制。
- **F-04 设备管理**：注册、能力发现、在线状态、独占占用、诊断、校准信息。
- **F-05 分布式接入**：既有 TCP/GPIB/USB 桥接兼容，Gateway 统一北向协议。
- **F-06 协同调度**：依赖、并行、互锁、租约、超时、失败分类与停止策略。
- **F-07 数据共享**：同一实验内共享实际状态、测量数据、证据及分析结果。
- **F-08 自治机制**：代理可提出建议，但跨设备状态改变需要受控仲裁。
- **F-09 安全与审计**：分权、审批、不可否认操作记录、设备安全策略。
- **F-10 可扩展**：新增驱动/Agent/实验模板无需修改核心运行时。

## 1.3 非功能需求（N）

| 编号 | 要求 | 设计目标（待实测验证） |
|---|---|---|
| N-01 | 设备控制安全 | 安全限制在边缘执行，LLM/Web 失联不解除互锁 |
| N-02 | 数据追溯 | 每个数据集关联实验、Run、任务、设备、校准与软件版本 |
| N-03 | 可恢复 | 网页刷新不丢任务；后端重启后进入状态核对流程 |
| N-04 | 事件可靠性 | 持久事件可重放，消费者可去重，UI 可断线补偿 |
| N-05 | 设备资源隔离 | 单设备单写入所有者，实验之间互斥或明确只读共享 |
| N-06 | 可观测性 | 请求、Agent、任务、网关、仪器链路有一致的追踪 ID |
| N-07 | 性能 | 点级快速采样留在本地；Web 实时展示采用限频聚合 |
| N-08 | 扩展性 | 网关、Agent 模板、测量模板采用稳定接口版本 |
| N-09 | 权限 | 以组织/实验室/项目/实验/设备为边界实施 RBAC 与策略授权 |
| N-10 | 可测试 | 全链路可切换模拟设备；上线前完成故障注入测试 |

## 1.4 明确不做的事情

初期**不做** LLM 微秒级反馈控制、不做无人工监督的跨设备高风险实验、不做未经授权的任意 SCPI 透传、不将 Agent 的聊天历史作为权威实验数据库、不承诺纯软件具备硬件安全认证能力。

---

# 2. 需求分析与用户旅程

## 2.1 三条核心用户旅程

### A. 创建并执行自主实验

1. 用户在 **Experiment Studio** 选择样品与可用仪器，描述实验目标。
2. Planner 根据能力目录生成 `PlanDraft`（任务、依赖、参数范围、预算、风险）。
3. Web 展示**可审查的任务图**；用户可以修改参数并选择“仅模拟/实际执行”。
4. Policy 与 Scheduler 检查项目权限、租约冲突、安全边界和审批要求。
5. 用户批准后，创建 `Run` 并调度任务；设备 Gateway 在本地执行扫描。
6. 实时数据和状态推送到 Web；分析 Agent 生成指标与提案。
7. Planner 可提交新增任务提案，但不能直接跳过用户授予的实验边界。
8. 实验结束后生成报告与完整追溯链。

### B. 设备接入和维护

1. 管理员在仪器中心添加 Gateway，完成设备身份校验。
2. Gateway 注册型号、连接方式、驱动版本、能力和安全策略版本。
3. 系统进行**只读**连通性与设备标识核验；写操作必须在授权测试模式下执行。
4. 管理员设置设备位置、共享级别、允许的实验模板、校准有效期。
5. 发布设备为 `AVAILABLE`；发生健康异常则自动转为 `UNAVAILABLE` 并暂停新任务。

### C. 数据复用与 Agent 协同

1. IV 测量完成，产生 `dataset.created` 事件和不可变数据集 ID。
2. Analysis Agent 读取同一 Experiment 的数据与实际场/温度时间序列。
3. Analysis Agent 保存结论、算法版本和证据数据集列表。
4. Planner 读取分析摘要，创建 `Proposal`。
5. Web 展示“新增测量建议—依据—成本—风险”，用户批准后转为新的 Task DAG。

## 2.2 用户故事与验收点

| 故事 | 验收点 |
|---|---|
| 研究人员看到仪器当前状态 | 界面清晰区分目标值/实际值/更新时间/是否过期 |
| 用户刷新浏览器 | 可以从服务端重建正在执行的任务与事件时间线 |
| 两个实验争用磁体 | 只有一个获得写租约，另一任务显示等待原因 |
| Planner 建议改变磁场 | 生成待审 Proposal，不会直接发送磁体命令 |
| Gateway 断开 | 状态标记失联；新写命令被拒绝；边缘按本地策略处理 |
| 消息重复送达 | 不会导致物理命令被重复执行 |
| 重启实验 | 对已下发但结果不明的任务先核对硬件状态，不盲重放 |

---

# 3. 系统总体架构与部署拓扑

## 3.1 九层架构 + 横切能力

| 层 | 组成 | 对外接口 | 状态归属 |
|---|---|---|---|
| L1 交互层 | Next.js、图表、任务图、对话 | HTTPS / SSE | 浏览器瞬态 UI |
| L2 应用层 | FastAPI、认证、实验/API、订阅 | REST / SSE / WS | 会话、用户、审批 |
| L3 Agent 智能层 | Planner、Measurement、Instrument、Analysis Agents | Agent Runtime 接口 | 建议、解释、计划草案 |
| L4 Agent Runtime | 模型适配、推理循环、工具注册、上下文与追踪 | 内部 RPC / SDK | Agent checkpoint、trace |
| L5 实验编排层 | Workflow Engine、Scheduler、Resource Manager、Policy | 命令与任务协议 | **任务/审批/设备租约的权威状态** |
| L6 数据与知识层 | PostgreSQL、HDF5/Zarr、对象存储、检索 | SQL / Dataset API | 实验元数据与原始数据 |
| L7 通信集成层 | NATS JetStream、Device Registry、MCP/RPC | Subject / RPC | 事件传递与服务发现 |
| L8 边缘仪器层 | Gateway、Driver、Local Executor、Safety Policy | TLS RPC / driver API | **真实设备当前状态的权威来源** |
| L9 物理设备层 | 源表、磁体、温控器、锁相/DAQ | TCP/GPIB/USB/触发线 | 真实物理状态 |

横切能力：**身份与授权、硬件安全、可观测性、版本治理、测试、备份恢复、配置和密钥管理**。

```mermaid
flowchart TB
  USER[研究人员 / Web 浏览器]
  subgraph FRONT[交互与应用]
    WEB[Next.js: Chat / Studio / Monitor / Data]
    API[FastAPI: REST + SSE]
    AUTH[认证 / RBAC / 审批]
  end
  subgraph CONTROL[智能与编排]
    AG[Agent Runtime]
    PLAN[Planner / Measurement / Analysis Agents]
    WF[Workflow Engine / Task Scheduler]
    RM[Resource Manager + Policy Engine]
  end
  subgraph STATE[数据与事件]
    PG[(PostgreSQL: 状态和审计)]
    BUS[NATS JetStream: 事件]
    OBJ[(HDF5 / Zarr: 数据文件)]
  end
  subgraph EDGE[分布式边缘]
    GW1[Gateway A + Local Executor + Safety]
    GW2[Gateway B + Local Executor + Safety]
    GW3[Gateway C + Local Executor + Safety]
  end
  HW1[源表 TCP/GPIB]
  HW2[磁体控制器 TCP]
  HW3[温控器 USB]
  USER --> WEB --> API
  API --> AUTH
  API --> AG --> PLAN
  PLAN --> WF --> RM
  RM --> BUS
  WF <--> PG
  AG <--> PG
  BUS <--> GW1
  BUS <--> GW2
  BUS <--> GW3
  GW1 --> HW1
  GW2 --> HW2
  GW3 --> HW3
  GW1 --> OBJ
  GW2 --> OBJ
  GW3 --> OBJ
  BUS --> API
  PG --> API
  OBJ --> API
```

> 图表示服务依赖而非放行路径：实际写命令须携带调度器签发/可验证的授权上下文，Gateway 本地再次校验；事件总线传递任务不会绕过边缘安全层。

## 3.2 部署拓扑：中央服务 + 各地 Gateway

```mermaid
flowchart LR
  subgraph SERVER[实验室服务器 / 受控内网]
    UI[Web + API]
    CORE[Agents + Scheduler]
    DB[(PostgreSQL)]
    MQ[NATS JetStream]
    FS[(共享数据/对象存储)]
  end
  subgraph LAB_A[实验室 A]
    PC1[Windows/Linux PC: Gateway A]
    VISA1[PyVISA / 已有 TCP 桥接]
    K[Keithley]
    PC1 --> VISA1 --> K
  end
  subgraph LAB_B[实验室 B]
    PC2[PC: Gateway B]
    MAG[磁体控制器]
    PC2 --> MAG
  end
  subgraph LAB_C[实验室 C]
    PC3[PC: Gateway C]
    TC[温控器]
    PC3 --> TC
  end
  UI --> CORE
  CORE --> DB
  CORE --> MQ
  CORE --> FS
  MQ <--> PC1
  MQ <--> PC2
  MQ <--> PC3
  PC1 -. 数据上传 .-> FS
  PC2 -. 数据上传 .-> FS
  PC3 -. 数据上传 .-> FS
```

**推荐部署方式**：Web/API/编排/Agent 初期部署在同一服务器（独立进程/容器），边缘 Gateway 作为独立进程在各仪器电脑运行。不同实验室可通过受控 VPN/零信任网络访问；默认采取**Gateway 主动建立出站连接**，避免直接对外开放 GPIB/USB 主机或仪器端口。离线时本地执行预批准的停机策略并缓冲日志，网络恢复后对账。

## 3.3 信任边界与故障隔离

- **浏览器不可信**：不能以隐藏按钮替代后端授权，不能从浏览器直连仪器。
- **LLM 不可信执行者**：输出永远视为建议或待验证的结构化计划。
- **消息传递非事务**：消息可能延迟/重复/乱序，Gateway 必须验证有效租约及命令状态。
- **Gateway 近端可信但可故障**：需要本地看门狗、日志落盘、失败安全状态。
- **数据库与真实设备可能不一致**：从 `UNKNOWN/RECONCILING` 状态恢复时必须查询设备实态。

---

# 4. Web 交互系统设计（重点）

## 4.1 信息架构与路由

| 页面 | 建议路由 | 页面主要元素 | 重要操作 |
|---|---|---|---|
| 登录 | `/login` | 身份认证 | 登录 / 退出 |
| 总览 | `/dashboard` | 在线设备、告警、活跃实验、队列 | 定位异常与进入详情 |
| Agent 工作区 | `/workspace/[experimentId]` | 会话树、聊天、任务时间线、工具记录 | 提问、提交计划、人工批准 |
| 实验列表 | `/experiments` | 搜索/筛选、样品/操作者/时间 | 创建实验、复制模板 |
| 实验 Studio | `/experiments/[id]/studio` | 配置面板、DAG 画布、参数表、审批 | 计划评审、模拟、启动、暂停 |
| 实验监控 | `/experiments/[id]/monitor` | 进度、实时曲线、实际环境量、告警 | 查看、暂停请求、停止请求 |
| 数据探索器 | `/data`、`/data/[datasetId]` | 数据集列表、曲线、元数据与溯源 | 对比、过滤、导出 |
| 仪器中心 | `/instruments`、`/instruments/[id]` | 状态/在线、能力、Gateway、日志 | 登记、维护、只读测试 |
| Agent 管理 | `/agents`、`/agents/[id]` | 角色、模型、工具、权限、自主等级 | 版本管理、启停模板 |
| 审批中心 | `/approvals` | 风险、提案、上下文、过期时间 | 批准/拒绝/撤销 |
| 系统与网关 | `/system/gateways`、`/settings` | 连接、监控、告警、角色、配置 | 管理运维 |

## 4.2 视觉/交互总体模式

**桌面三栏工作台（参考 ARTEX 的可见执行感，但面向实验）：**

```text
┌───────────────────────────────────────────────────────────────────────────────┐
│ ALAP  | 项目 / 样品                         运行状态●   告警(1)  用户菜单     │
├─────────────┬───────────────────────────────────┬─────────────────────────────┤
│ 实验与会话   │ Agent Workspace                   │ Live Execution               │
│             │                                   │                             │
│ + 创建实验   │ 用户: 测量磁场历史的零场整流      │ EXP-001 / RUN-002           │
│  EXP-001    │ Planner: 已生成实验计划            │ 任务 DAG                     │
│  EXP-002    │ [查看任务图] [查看依据]            │ ● 温度稳定 / 已完成         │
│             │                                   │ ● 正向磁场历史 / 已完成     │
│ 仪器状态     │ Analysis: 检测到异常，建议加测    │ ◉ IV 扫描 / 进行中          │
│  Keithley●  │ [查看证据] [审查提案]              │ ○ 分析 / 待执行             │
│  Magnet●    │                                   │                             │
│  Temp●      │ ┌─ Proposal P-012 ────────────┐  │ Keithley 当前: 12 μA        │
│             │ │ 磁场附近追加 5 个点（待审） │  │ Magnet 实测: 0.02 mT       │
│             │ │ [拒绝] [修改] [批准]        │  │ 温度: 2.003 K / 12s前     │
│             │ └────────────────────────────┘  │ [实时曲线] [审计]           │
├─────────────┴───────────────────────────────────┴─────────────────────────────┤
│ [实验目标 / 提问…]                               [附件] [发送]                │
└───────────────────────────────────────────────────────────────────────────────┘
```

在移动端，右栏折叠为“运行状态”抽屉；**关键审批必须完整显示风险与参数，不允许因窄屏隐藏关键信息**。

## 4.3 六大交互模块的组件清单

### A. Dashboard

- 仪器状态卡片：`Available / Busy / Offline / Maintenance / Fault / Stale`。
- 活跃实验：实验名、Run、负责人、所需设备、当前步骤、剩余队列（不伪造剩余时长）。
- 最新告警：仪器故障、任务审批、Gateway 失联、数据同步失败。
- 系统负载：排队任务、Agent 运行数、存储余量、模型调用成本（可选）。

### B. Agent Workspace

- 对话消息：文字、数据集引用、参数表、可展开工具调用卡片。
- 实时推理摘要：显示“计划/行动/证据/结果”，**不要求暴露模型内部私有推理过程**。
- 运行轨迹：角色、步骤、工具、输入参数（脱敏）、输出状态、耗时和 Trace ID。
- **Proposals**：证据、影响的设备、参数边界、成本、风险、审批要求。
- 人工介入：批准、拒绝、编辑计划、暂停后继续；写操作必须再经过服务端验证。

### C. Experiment Studio

- 左：仪器选择/参数范围/样品信息/工作流模板。
- 中：可视化 DAG（节点为任务，边为依赖），点击节点显示类型/状态/错误策略。
- 右：Plan 的结构化配置、预估资源、风险提示、审批状态。
- 操作区：`生成草案`、`验证`、`模拟运行`、`提交审批`、`启动`、`暂停`、`中止`。
- 编辑器生成的内容必须经过后端 DAG 校验（无环、资源、权限、数据类型）。

### D. Instrument Center

- 设备详情：`instrument_id`、型号、序列号、位置、当前连接、驱动版本、固件、校准状态。
- 能力：动作列表及 JSON Schema、支持的量程与只读/写权限。
- 实态：读数、采样时间、有效期、质量标志、实际占用和租约持有者。
- 维护：人工/服务模式切换；写入诊断操作须审批，避免在实验运行中抢占资源。

### E. Data Explorer

- 数据列表：实验、Run、任务、设备、样品、采集时间、文件大小、校验和。
- 曲线：IV、Ic(B)、温度、磁场时间轴；叠加实际值、目标值与数据质量掩码。
- 追溯：从曲线点跳转到 Task、Instrument State Snapshot、Agent Proposal 和校准记录。
- 导出：CSV/HDF5/JSON + 元数据清单；大量数据异步生成下载文件。

### F. Approvals & System Console

- 审批卡片：申请者、资源、操作、最大/最小值、变化速率、有效时窗、证据、拒绝原因。
- 运维屏：Gateway 在线、心跳、版本分布、告警、事件延迟、设备锁、死信队列。

## 4.4 交互状态设计

所有操作按钮必须与真实后端状态绑定，避免“界面按钮成功但设备未执行”的错觉。

| 操作 | 用户看到的过程 | 最终判定条件 |
|---|---|---|
| 启动实验 | 正在验证 → 等待审批/资源 → 正在执行 | Scheduler 确认 Run 进入 RUNNING |
| 设备写入 | 待调度 → 设备已接受 → 执行中 → 结果待确认 | Gateway 上报操作完成且实态核验通过 |
| 暂停 | 请求中 → 到达安全暂停点 → 已暂停 | Local Executor 上报 `PAUSED` |
| 中止 | 请求中 → 根据设备安全策略停止 → 状态核对 | 设备安全状态被验证，或明确提示需要人工干预 |
| 断线 | 连接中断，读数标注“过期” | 恢复通信并核对设备状态 |

## 4.5 实时通道设计

- **REST**：命令提交、资源查询、审批和导出。
- **SSE（优先）**：实验事件时间线、仪器状态低频更新、Agent 工具状态；浏览器断线携带 `Last-Event-ID` 补齐。适合服务端单向推送。
- **WebSocket（按需）**：双向协作编辑或交互式特性；不是设备硬实时通信方式。
- **大曲线**：Web 下载降采样数据块，实时事件只发送摘要与数据集/块指针。

---

# 5. 应用服务层与前后端接口设计

## 5.1 后端领域服务边界

| 服务 | 负责 | 不负责 |
|---|---|---|
| Identity / RBAC | 身份、组织、角色、项目授权 | 仪器底层驱动 |
| Experiment Service | 实验生命周期、样品、Run、模板 | LLM 逐步推理 |
| Agent Session Service | 用户聊天、Agent 实例、trace 索引 | 资源锁与硬件执行 |
| Workflow Service | Task DAG 持久化、状态机、状态恢复 | 直接发原始 SCPI |
| Device Service | 设备目录、能力、Gateway、遥测索引 | 仪器硬实时通信 |
| Approval Service | 审批请求、签署、撤销与有效期 | 取代硬件互锁 |
| Data Service | 数据集登记、元数据、下载、检索 | 在消息总线上推完整波形 |
| Event / Notification Service | 事件订阅、前端投递、告警 | 作为唯一的权威状态库 |

**实施策略**：这些在 MVP 可作为一个 FastAPI 项目中的独立模块，共享数据库和事务；只有达到明确扩容或故障隔离需求时，再拆成微服务。避免过早的分布式事务复杂性。

## 5.2 REST API 初版契约

| Method | 路径 | 描述 | 权限 |
|---|---|---|---|
| `POST` | `/api/v1/experiments` | 创建实验 | Researcher |
| `GET` | `/api/v1/experiments/{id}` | 读取实验详情 | Project viewer |
| `POST` | `/api/v1/experiments/{id}/plans:generate` | 请求生成 PlanDraft | Researcher |
| `POST` | `/api/v1/plans/{id}:validate` | 验证 DAG/资源/策略 | Researcher |
| `POST` | `/api/v1/experiments/{id}/runs` | 提交一次 Run | Operator + policy |
| `POST` | `/api/v1/runs/{id}:pause` | 请求暂停 | Operator |
| `POST` | `/api/v1/runs/{id}:stop` | 请求受控停止 | Operator |
| `GET` | `/api/v1/runs/{id}/tasks` | 任务列表及状态 | Project viewer |
| `GET` | `/api/v1/experiments/{id}/events` | SSE 事件订阅 | Project viewer |
| `GET` | `/api/v1/instruments` | 设备注册目录 | Authenticated |
| `GET` | `/api/v1/instruments/{id}/state` | 带时间戳实态 | Project viewer |
| `POST` | `/api/v1/proposals/{id}:review` | 修改/批准/拒绝建议 | Role + policy |
| `GET` | `/api/v1/datasets/{id}` | 数据集元数据 | Dataset reader |
| `GET` | `/api/v1/datasets/{id}/preview` | 降采样图表数据 | Dataset reader |
| `GET` | `/api/v1/agents/{id}/traces` | 代理执行记录 | Role + policy |

### 5.3 创建实验示例

**Request** `POST /api/v1/experiments`

```json
{
  "project_id": "proj-superconductivity",
  "name": "磁场历史与零场整流",
  "sample_id": "sample-A",
  "objective": "比较正负磁场历史后零外加场下的IV曲线",
  "instrument_ids": ["temp-01", "magnet-01", "smu-01"],
  "mode": "simulation"
}
```

**Response `201`（示例）**

```json
{
  "experiment_id": "exp-01JXAMPLE",
  "status": "DRAFT",
  "created_at": "2026-10-16T08:00:00Z",
  "links": {"self": "/api/v1/experiments/exp-01JXAMPLE"}
}
```

### 5.4 命令式 API 与错误格式

`POST` 类状态变化接口建议要求 `Idempotency-Key`，以及 `If-Match`/`expected_version` 防止前端编辑覆盖过时计划。

```json
{
  "error": {
    "code": "DEVICE_LEASE_CONFLICT",
    "message": "磁体正在被其他实验占用",
    "retryable": false,
    "correlation_id": "corr-1002",
    "details": {"instrument_id": "magnet-01"}
  }
}
```

常见错误类别：`UNAUTHORIZED`、`POLICY_DENIED`、`APPROVAL_REQUIRED`、`STALE_DEVICE_STATE`、`DEVICE_LEASE_CONFLICT`、`GATEWAY_OFFLINE`、`COMMAND_OUTCOME_UNKNOWN`、`DEVICE_INTERLOCK_ACTIVE`、`DATA_INTEGRITY_ERROR`。

---

# 6. Agent 系统与 Runtime 设计

## 6.1 Agent 角色、输入/输出和权限

| Agent | 输入 | 输出 | 可执行动作 | 自治边界 |
|---|---|---|---|---|
| Planner | 用户目标、设备能力、实验约束、分析结论 | `PlanDraft`、`Proposal` | 创建建议和计划草案 | **不可直接写设备** |
| Measurement Agent | 模板、目标条件、可用资源 | 可执行扫描子任务和依赖 | 申请调度执行高级工作流 | 不越过指定实验边界 |
| Instrument Agent | 该设备状态、能力、已授任务 | 操作参数建议、诊断、局部结果 | 调用经授权的设备工具 | 不能控制其他设备 |
| Analysis Agent | DataSet ID、分析目标、质量元数据 | `AnalysisArtifact`、异常、提案 | 读数据、运行受限计算工具 | 不具设备写权限 |
| Review Agent（可选） | 计划、数据、质量指标 | 审查意见 | 提交审查意见 | 不替代确定性安全规则 |

**重点**：一台仪器一个 Agent 是**逻辑隔离**，不要求一台仪器部署一个模型实例。多个 Instrument Agent 可共享一个模型服务；安全及点级采集由确定性程序负责。

## 6.2 Runtime 组件

```mermaid
flowchart LR
  CTX[Context Builder] --> LLM[Model Adapter]
  LLM --> PARSE[Structured Output Validator]
  PARSE --> TOOL[Tool Registry]
  TOOL --> AUTH[Authorization + Policy]
  AUTH --> EXEC[Tool Executor]
  EXEC --> TRACE[Trace / Event Log]
  TRACE --> MEM[Checkpoint / Memory]
  MEM --> CTX
```

- **Context Builder**：只取任务所需摘要、状态版本、设备能力、证据引用，不把全部数据塞入模型上下文。
- **Model Adapter**：兼容不同 LLM 提供方；支持配额、超时、失败降级。
- **Structured Output Validator**：使用 JSON Schema/Pydantic 校验工具参数，拒绝无法验证的输出。
- **Tool Registry**：每个工具声明作用域、风险等级、输入模式、版本及是否具有副作用。
- **Tool Executor**：区分只读工具、提案工具、已授权执行工具；所有设备写入最终经过 Scheduler。
- **Checkpoint**：保存 Agent 图节点执行状态，但**不是硬件设备实态**。
- **Trace**：保存可审查的工具调用、结果、错误、模型版本、prompt 版本及关联 ID。

## 6.3 Agent Loop 与状态机

```text
CREATED → READY → THINKING → TOOL_REQUESTED → WAITING_TOOL
                                         ├─→ WAITING_APPROVAL
                                         ├─→ WAITING_RESOURCE
                                         ├─→ PAUSED
                                         └─→ THINKING → COMPLETED
                                                     └─→ FAILED
```

Agent 自治回合必须设置硬边界：最大步骤数、预算、允许工具列表、最大任务持续时长、错误重试策略、人工停止开关。Planner 输出只能构成 `PlanDraft/Proposal`；调度器才能将审批通过的计划转成可执行 `Task`。

## 6.4 记忆的四类边界

1. **Conversation Memory**：聊天摘要、用户上下文；可编辑、可过期。
2. **Task Memory**：Agent 当前任务的阶段、结果与待办；使用 checkpoint。
3. **Experiment Shared State**：同一实验共享的结构化权威状态；由 Experiment Service 管理。
4. **Domain Knowledge**：仪器手册、驱动说明、实验 SOP、文献；检索时携带来源和版本。

**不把模型对话作为仪器真实状态或实验数据的唯一来源。** 实际数据必须从 Gateway/存储层取得。

## 6.5 工具层分类

| 类别 | 例子 | 默认权限 |
|---|---|---|
| 数据只读 | `get_experiment_state`、`read_dataset` | 依项目权限放行 |
| 计算只读/隔离 | `fit_iv_curve`、`estimate_ic` | 沙箱与资源配额 |
| 规划提案 | `create_proposal`、`generate_plan` | 允许但不可直接执行 |
| 设备写入 | `execute_iv_scan`、`set_field` | 必须经调度、租约、策略校验 |
| 原始命令 | `write_scpi_raw` | 默认不可向 LLM 暴露；仅维护模式人工受控 |

## 6.6 面向 ARTEX 的复用边界

可以借鉴：**Planner–Worker 分离、事件驱动的下一轮规划、共享任务清单、任务探索/知识溯源双视图、工具和 Runtime 解耦**。不应直接搬用：网络资产探索对象、渗透测试任务语义、默认可重试的纯软件操作模式。真实仪器需要设备状态核对、物理互锁、设备所有权及安全审批。

---

# 7. 多 Agent 协作：自治权、提案与仲裁

## 7.1 为什么不采用完全中心化或完全对等

**纯中心化**：Planner 为每个采样点发命令，模型延迟高、脆弱、难审计底层时序。  
**纯对等**：Agent 自发改变彼此设备参数，易资源争用、死锁、状态分歧、错误级联。  
**推荐混合式**：Planner 决策科研方向；设备 Agent 可以分析、协商和提出提案；Scheduler 统一仲裁跨设备状态改变；Gateway 完成本地执行。

## 7.2 自主等级

| 等级 | 能力 | 示例 | 上线建议 |
|---|---|---|---|
| L0 | 只读观测与解答 | 查询温度/磁场 | MVP |
| L1 | 执行已批准的固定模板 | IV 扫描 | MVP |
| L2 | 在预授权边界内微调非危险参数 | 增加测量重复次数/采样点 | P1 |
| L3 | 自主提出跨设备后续测量 | 检测异常后建议加测磁场 | P1 |
| L4 | 在研究人员批准的约束包络下执行多轮策略 | 自适应扫描 | P2，经验证 |

**注意**：高风险动作即使处于 L4，仍须满足独立策略、设备本地安全及可能的人工审批。

## 7.3 Agent 间通信协议

区分三种消息：

- **Observation**：可验证的观测事实，如 `field.actual = 0.0012 T @ timestamp`（必须有数据来源与时间）。
- **Proposal**：希望改变实验计划的建议，附数据证据、资源需求、成本和风险。
- **Approved Task**：Scheduler 发行的受控任务，附有效租约/审批引用；设备侧只消费此类写操作。

```mermaid
sequenceDiagram
    participant I as Instrument Agent
    participant P as Planner
    participant S as Scheduler/Policy
    participant G as Gateway
    participant D as Shared Data
    I->>D: 写入异常观测和证据索引
    I->>P: Proposal(加密磁场采样)
    P->>S: 提交 Plan Change
    S->>S: 依赖/设备租约/风险/权限检查
    alt 需要人工审批
        S-->>P: WAITING_APPROVAL
    else 已在授权范围内
        S->>G: Approved Task + lease/fencing
        G->>G: 本地互锁/参数检查
        G->>D: 数据集和设备实态
        G-->>S: Confirmed Result
    end
```

## 7.4 Proposal 示例

```json
{
  "proposal_id": "prop-012",
  "experiment_id": "exp-001",
  "author_agent": "analysis-agent",
  "kind": "REFINE_FIELD_GRID",
  "evidence_dataset_ids": ["ds-iv-034", "ds-iv-035"],
  "requested_resources": ["magnet-01", "smu-01"],
  "suggested_parameters": {"field_start_T": 0.035, "field_stop_T": 0.045, "step_T": 0.001},
  "reason": "该区域测得的临界电流变化较陡，建议提高采样密度",
  "status": "PENDING_REVIEW"
}
```

示例数字仅用于说明 Schema，不代表安全可执行范围；批准动作必须绑定策略版本与参数上限。

---

# 8. 实验工作流引擎与调度系统

## 8.1 为什么 Workflow Engine 不等于 Agent Runtime

Agent Runtime 管“思考与工具循环”；Workflow Engine 管“可持久恢复的业务任务”，包括依赖、互斥、等待、审批、取消、超时、设备状态对账。即使没有 LLM，实验执行也应可运行。

## 8.2 工作流节点类型

| 类型 | 说明 | 例子 |
|---|---|---|
| `SETPOINT` | 修改设备设定值 | 设置目标温度 |
| `WAIT_CONDITION` | 根据真实遥测判断稳定 | 规定窗口内温度波动满足要求 |
| `ACQUIRE` | 本地扫描与数据采集 | Keithley IV 扫描 |
| `ANALYZE` | 确定性数据处理 | 提取临界电流 |
| `BRANCH` | 基于结构化条件分支 | 异常则重测 |
| `PARALLEL` | 无资源冲突的并行子任务 | 同步监测多条只读传感器流 |
| `APPROVAL` | 等待人工/策略审批 | 升级磁场扫描范围 |
| `COMPENSATE` | 受控恢复/反向操作 | 按设备规定安全停止 |
| `REPORT` | 汇总结果和证据 | 生成实验报告 |

## 8.3 Run / Task 状态机

```mermaid
stateDiagram-v2
  [*] --> DRAFT
  DRAFT --> VALIDATED
  VALIDATED --> WAITING_APPROVAL
  VALIDATED --> QUEUED
  WAITING_APPROVAL --> QUEUED: approved
  WAITING_APPROVAL --> CANCELLED: rejected
  QUEUED --> LEASING
  LEASING --> RUNNING: lease acquired
  LEASING --> QUEUED: resource busy
  RUNNING --> SUCCEEDED: device confirmed
  RUNNING --> PAUSING
  PAUSING --> PAUSED: safe pause point
  PAUSED --> RECONCILING: resume requested
  RUNNING --> RECONCILING: disconnect/restart/outcome unknown
  RECONCILING --> RUNNING: reconciled and safe
  RECONCILING --> NEEDS_OPERATOR: uncertain physical state
  RUNNING --> FAILED
  RUNNING --> STOPPING
  STOPPING --> CANCELLED: safe stop confirmed
  STOPPING --> NEEDS_OPERATOR: cannot confirm safe state
  SUCCEEDED --> [*]
  FAILED --> [*]
  CANCELLED --> [*]
  NEEDS_OPERATOR --> [*]
```

**硬件操作的语义区分**：`REQUESTED`（业务请求）→ `ACCEPTED`（网关已接）→ `DISPATCHED_TO_DEVICE`（已下发）→ `DEVICE_REPORTED_DONE`（设备自报完成）→ `VERIFIED`（状态核验通过）。**不能**把 API `200 OK` 当作物理操作完成。

## 8.4 设备租约、fencing 和资源仲裁

- Scheduler 对一组设备以**规范化顺序**获取资源租约，避免不同任务循环等待。
- 租约有 `lease_id`、`owner_task_id`、`expires_at`、`fencing_token`。
- 每次新的有效控制者获得比上一次**更大的 fencing token**；Gateway 拒绝旧 token，即使旧进程误以为自己还持有锁。
- 过期租约**不等于可以立即把设备交给新任务**：若旧操作物理结果未知，先隔离设备并执行状态核对。
- 只读并发按设备驱动能力配置；部分老仪器的 `query` 也会改变状态，不应默认允许。

## 8.5 任务消息、幂等与“结果未知”

消息系统提供的可重投递并不等于物理动作具有 exactly-once 语义。必须分情况处理：

| 操作 | 重试策略 |
|---|---|
| 只读状态查询 | 通常可在超时后有限重试 |
| 幂等“设为固定目标值” | 核对状态、模式与策略后重试 |
| 增量动作 / 触发采集 | 不可盲重试；先根据 `command_id` 和设备状态核对 |
| 危险或不可逆动作 | 显式人工/设备侧确认；未确认时进入 `NEEDS_OPERATOR` |

Gateway 需持久保存命令去重账本，至少覆盖 `command_id` → `execution_state` → `device_confirmation`。命令请求与事件出站可采用 **Transactional Outbox** 保证数据库更新与待发布事件的原子记录；消费者侧建立 Inbox 去重表。

## 8.6 同步、稳定与超时

- 设备稳定需要满足阈值、持续窗口、变化率、读数新鲜度及状态质量要求。
- 多设备的硬同步由硬件触发 / DAQ / 同步时钟承担；SSE、NATS、Agent 事件仅用于软协调。
- 对所有等待条件设定超时和异常出口，超时不自动推断为“已稳定”。
- 温控/磁体类设备必须由本地确定性程序执行厂商规定的限幅、升降速率、联锁和断线策略。

## 8.7 示例工作流（磁场历史 + IV）

```mermaid
flowchart TD
  START([Create Run]) --> VALIDATE[验证样品/能力/审批/设备]
  VALIDATE --> LOCK[获取温控/磁体/SMU租约]
  LOCK --> TEMP[设置温度与等待稳定]
  TEMP --> HIST[执行获批磁场历史]
  HIST --> FIELD0[撤去外加场并核对实测磁场]
  FIELD0 --> IV[本地 IV 扫描 + 时间戳]
  IV --> DATA[提交不可变数据集和元数据]
  DATA --> ANALYSIS[分析 Ic+ / Ic- / 整流效率]
  ANALYSIS --> DECISION{建议追加测量?}
  DECISION -- 是 --> PROPOSAL[生成 Proposal → 审批/策略]
  PROPOSAL --> HIST
  DECISION -- 否 --> RELEASE[释放资源并生成报告]
  RELEASE --> END([Finish])
```

任何有环执行均需配置最大轮数/时间/预算和停止条件，不能允许无限自发循环。

---

# 9. 分布式仪器接入、Gateway 与现有桥接程序

## 9.1 三类现有桥接与改造路线

| 现状 | 保留部分 | 新增适配器 | 实施难度 |
|---|---|---|---|
| A 透明 TCP→GPIB/USB 转发 | 协议转发 | 结构化动作解释、白名单、状态/安全与日志 | 中 |
| B 已有 RPC/API 接口 | `set_x/read_y` | 统一 Schema、鉴权、租约、错误/版本 | 低至中 |
| C 已有完整扫描程序 | 测量流程与仪器驱动 | 高级 Task API、进度、取消/超时/数据登记 | 较低 |

**建议 Gateway 为包装层而非一次性重写**，保留稳定的底层桥接程序，通过 Adapter 将其统一到标准 Capability API。

## 9.2 Gateway 进程内部构成

```text
Gateway Service
├── Secure Transport (TLS / authenticated session)
├── Device Registration + Heartbeat
├── Capability Provider
├── Command Inbox + Persistent Dedup Ledger
├── Lease / Fencing Token Validator
├── Local Policy + Interlock Validator
├── Deterministic Task Executor
│   ├── Scan Controller
│   ├── Local Timeout / Watchdog
│   └── Safe Stop / Recovery Adapter
├── Telemetry Collector
├── Buffered Event Publisher / Dataset Uploader
└── Driver Adapter
    ├── Existing TCP Bridge
    ├── PyVISA / GPIB
    ├── USB / Vendor SDK
    └── Simulation Driver
```

## 9.3 标准设备能力描述（Capability Manifest）

```json
{
  "schema_version": "1.0",
  "instrument_id": "smu-01",
  "gateway_id": "gateway-lab-a",
  "vendor": "ExampleVendor",
  "model": "SourceMeter-X",
  "transport": "GPIB",
  "driver_version": "0.3.0",
  "capabilities": [
    {
      "name": "measure_iv",
      "version": "1.0",
      "risk_class": "CONTROLLED",
      "input_schema_ref": "schemas/measure_iv.v1.json",
      "required_resources": ["smu-01"],
      "supports_pause": false,
      "supports_cancel": true
    },
    {"name": "read_state", "version": "1.0", "risk_class": "READ_ONLY"}
  ],
  "health": {"connected": true, "last_seen": "2026-10-16T08:00:00Z"},
  "policy_ref": "device-policy-smu01-v3"
}
```

## 9.4 结构化执行命令

```json
{
  "schema_version": "1.0",
  "command_id": "cmd-005",
  "experiment_id": "exp-001",
  "run_id": "run-001",
  "task_id": "task-005",
  "instrument_id": "smu-01",
  "action": "measure_iv",
  "parameters": {
    "start_A": -0.00001,
    "stop_A": 0.00001,
    "points": 101,
    "compliance_V": 0.01
  },
  "lease_id": "lease-31",
  "fencing_token": 104,
  "approval_id": "approval-08",
  "policy_version": "device-policy-smu01-v3",
  "deadline": "2026-10-16T08:30:00Z"
}
```

**约束**：报文字段不是授权本身；Gateway 必须验证请求身份、任务签名/可信来源、有效租约 token、审批状态、策略版本及本地互锁；任何由客户端随意填写的 `approval_id` 不应直接被信任。

## 9.5 Gateway API 草案

| 操作 | 方向 | 语义 |
|---|---|---|
| `register_capabilities` | Gateway → Registry | 上报设备能力和版本 |
| `heartbeat` | Gateway → Registry | 网关/设备健康、当前租约和状态摘要 |
| `execute_task` | Scheduler → Gateway | 提交受控任务并返回受理凭证 |
| `get_task_status` | Scheduler → Gateway | 查询执行进度及结果确认 |
| `read_state` | 服务 → Gateway | 获取实测状态和采样时间 |
| `request_stop` | Scheduler → Gateway | 根据设备安全策略请求停止 |
| `reconcile_command` | Scheduler ↔ Gateway | 断线后核对任务和设备状态 |
| `publish_telemetry` | Gateway → Bus | 遥测流及状态质量标志 |
| `commit_dataset` | Gateway → Data Service | 登记数据集及校验和 |

**通信选择**：Gateway 可使用 gRPC/HTTP + TLS 进行命令控制，NATS JetStream 发送事件；弱网络环境优先长连接或出站反向连接。MCP 用于 Agent 工具发现/复用是可选层，**不宜直接作为安全控制的唯一边界**。

## 9.6 边缘故障策略矩阵

| 事件 | 边缘行为 | 中央行为 |
|---|---|---|
| Planner 无响应 | 不开启新任务，已授权任务按策略继续/终止 | 展示不可用、冻结自主规划 |
| 中央网络断开 | 本地缓冲日志；依据设备 SOP 处置输出 | 标记 `STALE/RECONCILING`，停止派新任务 |
| 设备本体断线 | 驱动记录错误、阻止后续写操作 | 置 `FAULT`，升级告警 |
| 设备超限/联锁 | 本地硬件/确定性逻辑立即生效 | 审计并通知人工 |
| Gateway 重启 | 先查询设备状态和命令账本，拒绝未知续执行 | 调度端核对后决定恢复 |
| 数据上传中断 | 本地暂存带校验和的数据块 | 数据状态显示 `UPLOADING/INCOMPLETE` |

---

# 10. 数据、知识、事件与实验溯源架构

## 10.1 三类存储职责

| 存储 | 存什么 | 不存什么 |
|---|---|---|
| PostgreSQL | Experiment、Run、Task、Proposal、Approval、Device、Lease、Dataset 元数据、Audit、Outbox | 大规模连续原始波形 |
| HDF5/Zarr + 文件/对象存储 | 原始测量数组、时序数据、导出文件、算法结果文件 | 频繁修改的任务协调状态 |
| NATS JetStream | 持久事件、状态变化、任务通知（去重） | 唯一权威状态、巨型原始数据文件 |

向量检索 / pgvector 用于仪器手册、SOP、论文的 RAG，作为后续增强模块；非 MVP 必需。

## 10.2 初版核心数据库表

| 表 | 核心字段 | 关键关系 |
|---|---|---|
| `users` | id, role, status | → memberships |
| `projects` | id, name, owner_id | → experiments |
| `samples` | id, project_id, metadata | → experiments |
| `experiments` | id, project_id, sample_id, objective, status, version | → runs |
| `runs` | id, experiment_id, plan_version, status, started_at, ended_at | → tasks |
| `plans` | id, experiment_id, version, json_dag, validation_status | → tasks |
| `tasks` | id, run_id, type, state, params, expected_version, status_reason | → task_dependencies |
| `task_dependencies` | task_id, depends_on_task_id | DAG 边 |
| `instruments` | id, gateway_id, model, capability_version, state | → device_states |
| `gateways` | id, hostname, status, last_seen_at, cert_id | → instruments |
| `device_states` | instrument_id, measured_at, received_at, quality, payload | 时间戳快照 |
| `resource_leases` | resource_id, owner_task_id, fencing_token, expires_at | → tasks |
| `commands` | id, task_id, instrument_id, device_phase, result, replay_policy | → task |
| `datasets` | id, run_id, task_id, uri, sha256, schema_version, quality | → analysis_artifacts |
| `analysis_artifacts` | id, dataset_ids, algorithm_version, params, result_uri | → proposals |
| `proposals` | id, experiment_id, author_agent_id, evidence_ids, state | → approvals |
| `approvals` | id, proposal_id, reviewer_id, decision, policy_version, expires_at | → tasks |
| `agent_sessions` | id, experiment_id, agent_config_version, checkpoint_ref | → agent_traces |
| `agent_traces` | id, session_id, task_id, span, model, tool, timestamp | 审计关联 |
| `audit_log` | id, actor_id, action, target, before, after, trace_id | 不可篡改策略 |
| `outbox_events` | event_id, type, payload, published_at | 事务性事件投递 |

生产数据库需要补充迁移脚本、索引、分区、约束以及权限模型；上表是逻辑 Schema，不是可直接上线的完整 DDL。

## 10.3 ER 图（简化）

```mermaid
erDiagram
  PROJECT ||--o{ EXPERIMENT : contains
  SAMPLE ||--o{ EXPERIMENT : measured_in
  EXPERIMENT ||--o{ RUN : has
  EXPERIMENT ||--o{ PLAN : has
  RUN ||--o{ TASK : executes
  TASK ||--o{ COMMAND : issues
  TASK ||--o{ DATASET : produces
  INSTRUMENT ||--o{ COMMAND : receives
  GATEWAY ||--o{ INSTRUMENT : hosts
  DATASET ||--o{ ANALYSIS_ARTIFACT : analyzed_by
  EXPERIMENT ||--o{ PROPOSAL : suggests
  PROPOSAL ||--o{ APPROVAL : reviewed_by
  TASK ||--o{ RESOURCE_LEASE : owns
```

## 10.4 DataSet Manifest 示例

```json
{
  "dataset_id": "ds-iv-034",
  "schema_version": "1.0",
  "experiment_id": "exp-001",
  "run_id": "run-002",
  "task_id": "task-014",
  "instrument_id": "smu-01",
  "sample_id": "sample-A",
  "acquired_at": "2026-10-16T08:12:31.430Z",
  "storage_uri": "datasets/exp-001/run-002/ds-iv-034.h5",
  "sha256": "<computed-on-completed-file>",
  "axes": ["current_A"],
  "signals": ["voltage_V"],
  "environment_refs": ["temp-stream-08", "magnet-stream-11"],
  "device_actual_state_ref": "state-snapshot-312",
  "calibration_version": "smu-cal-2026-02",
  "driver_version": "smu-driver-0.3.0",
  "quality": "VALIDATED",
  "analysis_refs": ["analysis-008"]
}
```

### 数据完整性协议

1. Gateway 本地以临时路径写入数据，记录采样时钟与质量标志。
2. 扫描结束后 flush / close，计算校验和，标记 `READY_TO_UPLOAD`。
3. 上传数据文件（可断点续传）；Data Service 核验完整性。
4. 数据集元数据在事务内置为 `AVAILABLE`，写出 `dataset.created` Outbox 事件。
5. Agent 只有在数据处于 `AVAILABLE` 且授权通过后，才能作为有效实验数据引用。
6. 原始数据保持不可变；重分析产生新 `AnalysisArtifact`，不能覆盖原始文件。

## 10.5 共享状态≠共享对话

所有 Instrument Agents 应通过 `experiment_id` 获取同一次实验的**当前权威状态快照**和相关数据集索引，而不是相互复制全部聊天历史。每条观测需带：`instrument_id`、`measured_at`、`received_at`、单位、质量标志与过期规则。目标设定值与实测值必须分开；“设置为 50 mT”不意味着“当前为 50 mT”。

## 10.6 事件模型与命名规范

Subject 示例：

```text
experiment.exp-001.run.started
experiment.exp-001.task.state_changed
instrument.smu-01.telemetry.updated
instrument.magnet-01.interlock.tripped
measurement.ds-iv-034.available
agent.analysis-01.proposal.created
approval.appr-008.resolved
```

统一事件包：

```json
{
  "event_id": "evt-1001",
  "schema_version": "1.0",
  "event_type": "measurement.dataset.available",
  "occurred_at": "2026-10-16T08:12:32Z",
  "recorded_at": "2026-10-16T08:12:33Z",
  "experiment_id": "exp-001",
  "run_id": "run-002",
  "task_id": "task-014",
  "causation_id": "cmd-005",
  "correlation_id": "corr-1002",
  "payload": {"dataset_id": "ds-iv-034"}
}
```

- 事件具有唯一 ID，消费者按 `event_id` 去重；不同生产者间**不假定全局严格顺序**。
- 关键状态变更入 PostgreSQL，NATS JetStream 用于分发/重放；不能只靠浏览器 WebSocket 记录事实。
- 采用 Schema version，并为消息兼容性建立测试。

## 10.7 ARTEX 双图思想如何落地

**Experiment Knowledge Graph** 记录实验—样品—仪器—数据集—结论的实体关系。  
**Execution/Exploration Graph** 记录计划—任务—命令—事件—分析—新提案的因果与执行关系。

**MVP 优先以关系表 + `relations` 边表 + trace 查询实现**，待真正出现跨实验复杂图查询时再评估 Neo4j 等图数据库，避免为“图”而图。

---

# 11. 安全、权限与高可靠性设计

## 11.1 安全控制优先级

```text
物理急停/硬件联锁（最高优先级）
    > 仪器内部保护与本地控制器策略
    > Gateway 本地 Safety Policy
    > 中央 Scheduler/Policy + Approval
    > Agent 的工具许可 / Prompt
    > Web UI 操作约束（最低优先级）
```

不得以软件审批替代磁体、低温、电源系统的厂商安全保护与现场 SOP。对超导磁体等设备，“立即断电”未必等于安全停止；具体策略由设备专家审定。

## 11.2 典型策略

- **参数边界**：限制设定值、变化率、保持时间、功率、compliance、输出模式。
- **互锁条件**：冷却状态、真空状态、磁体状态、样品保护条件、机柜安全状态。
- **数据新鲜度**：不得用过期读数确认稳定；异地遥测异常应阻止下一危险步骤。
- **权限分离**：Researcher 可提案；Operator 可启动批准流程；维护角色才能开放受控原始命令。
- **审批双人原则（可选）**：特定高风险磁场/电源操作由两名具资质人员批准。
- **安全暂停点**：扫描中途中断不能凭 Web 按钮假定立即停下，Gateway 必须实现可验证暂停/停止。

## 11.3 最小角色矩阵

| 动作 | Observer | Researcher | Operator | Instrument Admin | System Admin |
|---|---:|---:|---:|---:|---:|
| 查看授权实验数据 | ✓ | ✓ | ✓ | 按需 | 按需 |
| 生成计划草案 | — | ✓ | ✓ | — | — |
| 运行模拟实验 | — | ✓ | ✓ | 可选 | — |
| 提交真实设备任务 | — | 申请 | ✓（策略约束） | 维护范围 | — |
| 审批高风险设备操作 | — | — | 具资质者 | 具资质者 | 不自动获得 |
| 修改设备策略 | — | — | — | ✓（审核后） | 平台级管理 |
| 改模型和服务配置 | — | — | — | — | ✓ |

RBAC 外还需 ABAC：项目、设备组、工作时段、实验边界、资质、维护模式等上下文策略。管理员角色**不默认意味着具备磁体操作资质**。

## 11.4 危险工具分级与审批

| 风险级别 | 例子 | 执行原则 |
|---|---|---|
| R0 | 查询设备状态 | 自动放行，按权限限流 |
| R1 | 只读数据处理 | 自动放行，计算沙箱隔离 |
| R2 | 预批准范围内采样 | 一次批准，Task 内受控执行 |
| R3 | 改变设备设定值或扩展范围 | 依据设备策略和审批矩阵 |
| R4 | 可能导致损坏、失超、危险输出的操作 | 人员现场监督及硬件级保护，默认禁止自治执行 |

## 11.5 远程安全

- TLS/mTLS、服务身份，密钥轮换；Gateway 只允许受信控制平面访问。
- 实验室网段隔离；不将仪器控制端口直接暴露到互联网。
- Web 采用安全 Cookie、CSRF 防护（使用 Cookie 会话时）、CSP、输入校验、审计日志。
- Agent 可能处理恶意文档/仪器返回文本，检索结果与工具输出视为不可信输入，防 Prompt Injection 诱导高风险工具使用。
- 维护原始命令模式须单独认证、记录并强制设备独占，不对普通 Agent 暴露。
- 敏感实验数据实施项目级授权及备份加密。

## 11.6 故障恢复的正确性边界

**绝不能因为 LangGraph 的 checkpoint 表示“工具未返回”，就直接重发上一个硬件动作。**

恢复流程应为：

1. Scheduler 检测失联/超时，将 Task 标为 `RECONCILING`。
2. 查询 Gateway 持久命令账本和仪器当前实态。
3. 若可确认已完成且符合目标，补记结果；若未开始且仍有效，则允许重新调度。
4. 若执行结果无法确认、设备状态不可信或恢复不安全，则进入 `NEEDS_OPERATOR`，暂停相关资源。
5. 只有通过核对后才能发起后续任务，并保留审计证据。

---

# 12. 可观测性、部署与运维

## 12.1 端到端可观测性

统一 `trace_id` / `correlation_id` 贯穿：

```text
UI Action
  → API Request
    → Agent Session
      → Planner Proposal
        → Scheduler Task
          → Gateway Command
            → Instrument Telemetry / Dataset
              → Analysis Artifact
```

观测维度：日志（JSON 结构化）、指标（在线率、事件滞后、任务排队、执行失败率、设备数据新鲜度、LLM 成本）、分布式追踪（OpenTelemetry 可选）、用户可见执行时间线。

## 12.2 服务部署建议

```text
central-server/
  reverse-proxy
  nextjs-web
  fastapi-api
  agent-runtime-worker
  scheduler-worker
  postgres
  nats-jetstream
  dataset-store
  monitoring (later)

lab-pc-a/
  gateway-service
  instrument-adapters
  local-safety-policy
  durable-command-ledger
  local-spool

lab-pc-b/ ...
```

首期使用 Docker Compose 运行中央服务；Gateway 可安装成 Windows Service / systemd 服务。仪器驱动是否容器化取决于驱动及硬件接口兼容性，不强制使用 Docker 控制 GPIB/USB。

## 12.3 数据与事件备份

- PostgreSQL：定时备份与恢复演练；迁移前备份并记录 Schema 版本。
- HDF5/Zarr：多副本/快照、校验和、数据保留策略；备份目标与目录权限隔离。
- JetStream：合理持久化与保留期；事件归档/Outbox 是业务事件审计长期依据。
- Agent checkpoints：保留与 Experiment/Run 的稳定关联；过期清理策略须不破坏追溯。
- 事故审计：审批、设备控制、策略修改日志采用限制修改与备份/归档策略。

## 12.4 运维告警

| 告警 | 严重级别 | 初步动作 |
|---|---|---|
| 设备互锁触发 | Critical | 边缘按 SOP 执行保护；通知值班人员 |
| 设备输出状态无法确认 | Critical | 资源隔离、停止派单，等待人工核对 |
| Gateway 心跳超时 | High | 仪器标记 STALE；阻止新写任务 |
| 数据上传校验失败 | High | 标记数据不可用，按块重传，不修改原始数据 |
| 事件积压过高 | Medium | 限制新任务与分析频率，检查消费端 |
| 模型服务不可用 | Medium | 暂停规划，不影响本地设备安全流程 |

---

# 13. 工程实现：技术栈、代码结构与模块契约

## 13.1 技术选型（建议而非硬性绑定）

| 子系统 | MVP 首选 | 后续替代/增强 | 备注 |
|---|---|---|---|
| 前端 | Next.js + TypeScript | React 单页应用 | SSR 非核心要求 |
| UI | Tailwind CSS + 组件库 | 自定义设计系统 | 保持一致状态反馈 |
| 工作流图 | React Flow | 其他 DAG Editor | P1；MVP 只读图也可 |
| 图表 | Plotly.js / ECharts | 专用 WebGL 绘图 | 高频数据先降采样 |
| API | FastAPI + Pydantic | Go / NestJS | Python 科研生态友好 |
| Agent 编排 | LangGraph | OpenAI Agents SDK + 自建工作流 | LLM Agent 的编排，不替代设备调度 |
| 任务 Scheduler | 独立 Python 模块（Postgres 状态机） | Temporal 等持久工作流引擎 | 早期避免两个调度引擎重复掌权 |
| 通信 | REST + SSE | WebSocket | 前端实时事件 |
| 总线 | NATS JetStream | Kafka / RabbitMQ | 持久消息需消费者去重 |
| 数据库 | PostgreSQL | + TimescaleDB | 设备遥测可分区 |
| 科学文件 | HDF5 | Zarr / 对象存储 | 大规模或并发场景可选 Zarr |
| 驱动 | PyVISA + QCoDeS + vendor SDK | Bluesky / Ophyd | 根据仪器驱动成熟度选择 |
| Gateway | Python Service + existing bridge adapters | Go / Rust | 独立边缘进程 |
| 模型接口 | 统一 Provider Adapter | 本地模型服务 | 模型不直接获设备控制权限 |
| 认证 | OIDC（可复用学校认证） | 自建账户仅用于原型 | 生产避免重复造认证系统 |
| 测试 | pytest + Playwright + 模拟设备 | HIL 专项测试 | 先虚拟再真实 |
| 部署 | Docker Compose + systemd/Windows Service | Kubernetes | 非必要不先上 K8s |

## 13.2 Monorepo 目录规划

```text
alap/
├── apps/
│   ├── web/                          # Next.js
│   │   ├── app/(auth)/login/
│   │   ├── app/(main)/dashboard/
│   │   ├── app/(main)/workspace/[experimentId]/
│   │   ├── app/(main)/experiments/[id]/studio/
│   │   ├── app/(main)/experiments/[id]/monitor/
│   │   ├── app/(main)/instruments/[id]/
│   │   ├── app/(main)/data/[datasetId]/
│   │   ├── app/(main)/agents/
│   │   ├── app/(main)/approvals/
│   │   ├── app/(main)/settings/
│   │   ├── components/
│   │   ├── hooks/
│   │   └── lib/api/
│   └── api/                          # FastAPI
│       ├── api/v1/
│       ├── modules/auth/
│       ├── modules/experiments/
│       ├── modules/devices/
│       ├── modules/approvals/
│       ├── modules/datasets/
│       ├── modules/events/
│       ├── db/
│       └── main.py
├── services/
│   ├── agent_runtime/
│   │   ├── agents/{planner,measurement,instrument,analysis}/
│   │   ├── context/
│   │   ├── models/
│   │   ├── tools/
│   │   ├── checkpoints/
│   │   └── tracing/
│   ├── workflow_engine/
│   │   ├── dag/
│   │   ├── scheduler/
│   │   ├── leases/
│   │   ├── reconciler/
│   │   └── policy/
│   ├── device_registry/
│   ├── event_dispatcher/
│   └── data_service/
├── edge/
│   ├── gateway/
│   │   ├── server/
│   │   ├── commands/
│   │   ├── state/
│   │   ├── safety/
│   │   ├── watchdog/
│   │   └── spool/
│   ├── adapters/
│   │   ├── existing_tcp_bridge/
│   │   ├── pyvisa/
│   │   ├── qcodes/
│   │   └── vendor_sdk/
│   ├── drivers/
│   └── simulators/
├── packages/
│   ├── schemas/                    # JSON Schema / OpenAPI / events
│   ├── python_sdk/
│   └── typescript_sdk/
├── infra/
│   ├── docker-compose.yml
│   ├── database/migrations/
│   └── monitoring/
├── tests/
│   ├── unit/
│   ├── contract/
│   ├── e2e/
│   ├── fault_injection/
│   └── hardware_in_loop/
└── docs/
    ├── architecture/
    ├── adr/
    ├── api/
    ├── safety/
    └── user_guides/
```

## 13.3 主要代码接口（Python 伪代码）

```python
from typing import Protocol, Any
from dataclasses import dataclass

@dataclass(frozen=True)
class InstrumentState:
    instrument_id: str
    measured_at: str
    quality: str
    values: dict[str, Any]

@dataclass(frozen=True)
class AuthorizedTask:
    task_id: str
    command_id: str
    instrument_id: str
    action: str
    parameters: dict[str, Any]
    lease_id: str
    fencing_token: int
    authorization_ref: str

class InstrumentGateway(Protocol):
    async def capabilities(self) -> dict: ...
    async def read_state(self) -> InstrumentState: ...
    async def execute(self, task: AuthorizedTask) -> str: ...
    async def get_execution_status(self, command_id: str) -> dict: ...
    async def request_safe_stop(self, command_id: str) -> dict: ...

class ExperimentScheduler(Protocol):
    async def submit_plan(self, experiment_id: str, plan: dict) -> str: ...
    async def approve(self, proposal_id: str, reviewer_id: str) -> str: ...
    async def get_run_status(self, run_id: str) -> dict: ...
```

上述代码仅用于定义边界；生产实现还要加认证、Schema 验证、设备状态转换和本地安全保护。

## 13.4 模块接口责任约束

| 调用方 → 被调用方 | 允许行为 | 禁止行为 |
|---|---|---|
| UI → API | 创建实验、订阅事件、提交审批 | 浏览器直接访问设备 |
| Planner → Workflow | 提交计划/提案 | 直接签发设备控制租约 |
| Scheduler → Gateway | 提交**已授权**任务 | 绕过本地安全检查 |
| Instrument Agent → Data | 读取授权实验数据、发布提案 | 篡改原始数据 |
| Gateway → Data | 上传数据文件和元数据 | 自行决定跨设备下一轮科研目标 |
| Analysis → Planner | 提供指标、误差、证据引用 | 将单次异常直接认定为物理结论 |

## 13.5 工程开发规范

- 所有 API 与事件 Schema 建立版本，优先定义契约再实现。
- Task/Command/Event/Agent Trace 必须具备链路追踪标识。
- `setpoint` 与 `measured` 必须使用不同字段；全部数据带物理单位。
- 与硬件相关的配置使用有版本控制的 Device Policy，不硬编码在 Prompt 中。
- 模拟驱动和真实驱动共享相同的高层接口，集成测试能切换。
- 原始数据和分析派生数据分离；算法版本与输入数据必须记录。
- 危险操作需手动审查 PR，接入新仪器先跑模拟再上台架。

---

# 14. 开发路线、里程碑和验收标准

## 14.1 分期交付

| 阶段 | 核心目标 | 主要交付 | 进入下一阶段的门槛 |
|---|---|---|---|
| **P0 — 需求/安全基线** | 设备清单、命令约束、现有桥接摸底 | 仪器接口表、风险分级、ADR、安全策略模板 | 明确每台设备安全停止/恢复语义 |
| **P1 — Web MVP** | 产品交互骨架 | 登录/总览/实验/Workspace/任务时间线/Mock 数据 | 浏览器能完整走通模拟实验交互 |
| **P2 — Runtime + Workflow** | 任务和 Agent 真实运行 | Planner、Agent Loop、DAG、审批、Scheduler、trace | 模拟设备多任务与审批测试通过 |
| **P3 — Gateway + 模拟仪器** | 分布式可靠接入 | Gateway、Registry、能力 Schema、local executor | 模拟断线/重连/重复投递无危险重放 |
| **P4 — 数据共享闭环** | 多代理可复用数据 | DataSet、Data Explorer、实际环境遥测关联 | 从测量到分析再到 Proposal 全链可追踪 |
| **P5 — 首台真实仪器试点** | 物理设备安全验证 | 只读→受控单设备测量→多设备联动 | 由仪器负责人签署试点验收 |
| **P6 — 动态自治增强** | 有边界的自适应实验 | L2/L3 自治、动态加测、模板库 | 策略、审批和异常恢复回归测试通过 |
| **P7 — 生产运维** | 多实验室长期部署 | 监控、备份、审计、故障演练、多用户配额 | 完整 SLO、恢复演练、维护流程 |

> 阶段是依赖关系而非固定日历：若团队较小，可先用单库单服务完成 P1–P4；涉及真实仪器前，所有相关安全门槛不可省略。

## 14.2 首个可交付 MVP：三台模拟仪器

**目标**：从浏览器输入“设置温度、设置磁场、扫描 IV、分析并提出加测建议”，Web 全程可见，并生成有证据链的数据集。

**模拟设备**：`TempSim`、`MagnetSim`、`SourceMeterSim`。  
**参与 Agent**：`Planner`、`Instrument Agents`、`Analysis Agent`。  
**必备服务**：Next.js、FastAPI、Agent Runtime、Scheduler、PostgreSQL、Gateway Simulator、文件存储；JetStream 在 MVP 可通过独立模块接入，但事件契约必须先定。

验收测试：

- [ ] 浏览器可创建实验并查看任务 DAG。
- [ ] Planner 输出结构化计划、资源需求和参数边界。
- [ ] 模拟实验可以被审批、启动、暂停、停止和查询。
- [ ] 三台模拟仪器各自拥有独立状态，统一参与一个 Experiment。
- [ ] 只有在温度/磁场满足**模拟稳定条件**时才启动 IV。
- [ ] 实时曲线和进度可以在 Web 展示，刷新页面可恢复。
- [ ] 原始 IV 数据与实际模拟温度/磁场时间序列关联。
- [ ] Analysis Agent 产生结论和 Evidence-linked Proposal。
- [ ] 两个并发实验争用磁体时，至少一个排队且原因可见。
- [ ] 断线、消息重复、重启后，危险动作不会被盲目重发。
- [ ] 每次命令和审批具有完整审计记录。

## 14.3 真实仪器接入验收

- [ ] 设备型号、固件版本与驱动命令行为完成实测核对。
- [ ] 本地安全限值和输出停止策略经设备负责人审查。
- [ ] 掉线、超时、设备重启、异常读数测试有书面结论。
- [ ] 命令去重与任务恢复符合该设备具体语义。
- [ ] 时间戳、新鲜度、单位和校准信息可查询。
- [ ] Web 页面显示“设备已确认”而不只是“请求已发送”。
- [ ] 急停、联锁和现场人工接管可在中心服务失联时生效。
- [ ] 设备管理员批准后，才允许真实控制任务上线。

## 14.4 风险清单与优先级

| 风险 | 影响 | 对策 | 级别 |
|---|---|---|---|
| LLM 幻觉产生危险参数 | 设备/样品受损 | Schema + Policy + 现场互锁 | 极高 |
| 消息重发重复触发动作 | 设备状态异常 | command ledger + fencing + reconciliation | 极高 |
| 跨实验争抢设备 | 数据无效/设备冲突 | 资源租约、设备独占 | 极高 |
| 传感器数据过期 | 错判稳定 | 时戳、TTL、质量标志、阻断执行 | 高 |
| 网关/网络断开 | 测量中断/状态不明 | 边缘 watchdog + 缓冲 + 核对 | 高 |
| 磁场/温度设定与实态混淆 | 科研结论错误 | 双字段 + 同步采样 + 溯源 | 高 |
| 微服务过早拆分 | 开发/运维复杂 | 模块化单体、清晰契约 | 中 |
| 高成本模型调用 | 长实验费用高 | 实验级 LLM 决策，本地点级执行 | 中 |

## 14.5 立项后第一轮待确认信息

以下不是继续设计的阻塞项，但决定真实设备试点顺序：

1. 仪器型号、厂家、数量、控制机 OS、TCP/GPIB/USB 物理拓扑。
2. 已有桥接程序是透明转发、RPC，还是支持本地扫描；源码是否可改。
3. 哪些设备属于高风险设备，现有安全 SOP 和急停机制是什么。
4. 典型实验的数据采样频率、文件体积、并行任务数量与同步精度。
5. Web 用户数、实验室网段限制、是否有校园身份系统/OIDC。
6. 是否需要完全离线/本地 LLM，以及项目预算和部署环境。

---

# 15. 端到端场景：超导器件“磁场历史 → 零场 IV → 自适应加测”

> 本章用于把前端、Runtime、Scheduler、数据层、Gateway 串成完整产品流程。数值只是说明实验逻辑，不能直接作为真实仪器操作方案。

## 15.1 一次实验如何从 Web 发起

1. **Web**：用户选择样品、磁体、温控器和源表，输入研究目标。
2. **API**：创建 `Experiment`，分配 `exp-001`，将所有状态持久化。
3. **Planner**：读取 Device Registry 中的能力与安全包络，生成 PlanDraft。
4. **Studio**：可视化显示“温度稳定→磁场历史→撤去外场→IV→分析”。
5. **Policy**：检查用户资格、设备安全限制、资源争用与审批需求。
6. **用户**：查看计划差异、风险和预计资源；批准后创建 Run。
7. **Scheduler**：依赖/租约校验后派发授权任务。
8. **Gateway**：本地控制器校验命令并实际操作仪器；产生状态和数据。
9. **Data Service**：接收并校验数据，建立 Dataset 与 Task/设备状态关系。
10. **Analysis Agent**：计算指标并识别需要加测的区域；产生 Proposal。
11. **Planner + 用户/策略**：批准或拒绝加测；批准则追加有版本的 Task DAG。
12. **Web**：实时显示最终曲线、执行来源、审批历史和报告。

## 15.2 关键时序图

```mermaid
sequenceDiagram
    actor U as User
    participant W as Web UI
    participant API as Application API
    participant P as Planner
    participant S as Scheduler/Policy
    participant T as Temp Gateway
    participant M as Magnet Gateway
    participant K as SMU Gateway
    participant D as Data Service
    participant A as Analysis Agent

    U->>W: 输入实验目标
    W->>API: POST /experiments
    API->>P: Generate PlanDraft
    P-->>W: PlanDraft + 风险与依赖
    U->>W: 审核/批准
    W->>API: POST /runs
    API->>S: Submit Authorized Plan
    S->>T: SETPOINT + Lease
    T-->>S: 温度稳定（实测确认）
    S->>M: Approved Field History
    M-->>S: 外加场撤去并确认
    S->>K: Execute IV Scan
    K->>D: 上传 HDF5 + 状态溯源
    D-->>API: dataset.available event
    API-->>W: SSE 实时显示数据集
    S->>A: 分析数据集
    A-->>P: Analysis + Proposal
    P-->>W: 提议加测（待审）
    U->>W: 批准/拒绝
    W->>API: Review Proposal
    API->>S: 新增任务或结束实验
```

## 15.3 复盘界面应能够回答的十个问题

- 谁提出实验目标？
- 谁生成计划？使用了哪个模型与 Prompt 版本？
- 哪些仪器真正参与？具体 Gateway/驱动/固件版本是什么？
- 每个任务获批的参数边界是什么？
- 每次设备写入由谁批准、何时批准？
- 设备报告的**实际**温度和磁场是多少？数据是否过期？
- IV 曲线在什么时间采集？有没有缺点/合规限制触发？
- 分析结论来自哪些数据集与算法版本？
- Planner 为什么提议追加实验？证据何在？
- 网络中断/任务恢复后是否发生过状态核对？

---

# 16. 第一批研发任务（可直接建 Issue）

| Issue | 名称 | 前置 | 验收产物 |
|---|---|---|---|
| EPIC-01 | 定义 `Experiment/Run/Task/Event` Schema | 无 | OpenAPI + JSON Schemas |
| EPIC-02 | Web Shell：Layout、导航、登录、Dashboard | EPIC-01 | 可访问的 5 个关键页面原型 |
| EPIC-03 | 实验创建与查询 API | EPIC-01 | CRUD + RBAC + 数据迁移 |
| EPIC-04 | Agent Runtime：计划草案生成 | EPIC-01 | PlanDraft、trace、模型适配 |
| EPIC-05 | Scheduler DAG 状态机 | EPIC-01 | 依赖检查/锁/审批/测试 |
| EPIC-06 | Instrument Gateway SDK + Sim Driver | EPIC-01 | 三种模拟设备 |
| EPIC-07 | 实验执行 SSE 事件投影 | EPIC-03/05 | 刷新、断线补偿、时间线 |
| EPIC-08 | Dataset 生命周期与数据浏览 | EPIC-03/06 | HDF5、校验、可视化 |
| EPIC-09 | 设备 Registry 和仪器详情 | EPIC-06 | 在线/失联/能力展示 |
| EPIC-10 | Proposal → Approval → Run | EPIC-04/05 | 审批卡片 + 审计 |
| EPIC-11 | 故障注入与安全闸门 | EPIC-05/06 | 断线、重发、失联、恢复测试 |
| EPIC-12 | 第一台真实仪器试点 | EPIC-11 | 经设备负责人验收的接入记录 |

建议将每个 EPIC 再拆为前端、后端、Schema、测试、安全五类子任务，以 API 契约作为并行开发的连接点。

---

# 附录 A：最小开发环境与运行顺序

**开发端**：Node.js、Python、PostgreSQL、NATS（可选前期模拟）、测试数据集、3 个 Sim Gateway；不连接任何真实设备也能演示完整产品流程。

**建议启动顺序**：

1. PostgreSQL + Schema migrations。
2. API Server + Identity（初期可用测试账户）。
3. Sim Gateway + Device Registry。
4. Scheduler + Event Dispatcher。
5. Agent Runtime 与 Analysis Worker。
6. Next.js Web + SSE 客户端。
7. 运行端到端模拟脚本与故障注入测试。

**上线前替换**：模拟身份换 OIDC、模拟 Gateway 换真实 Gateway、演示安全策略换经设备负责人批准的策略、调试日志换正式审计与保留机制。

# 附录 B：平台事件驱动与控制路径的区别

**事件路径（通知与感知）**：`Device → Gateway → Event Bus → State/Projection → UI & Agents`。  
**受控命令路径（有副作用）**：`User / Agent Proposal → Scheduler + Authorization + Lease → Gateway Safety → Driver → Device → Physical Confirmation`。  
**数据路径（大数据）**：`Local Executor → HDF5/Zarr → Data Service Verify → Dataset Metadata → Event Reference → Analysis/UI`。

这三条路径的分离，是本项目实现**Web 可观测性、Agent 自主性与物理设备安全**三者兼得的关键。

# 附录 C：技术资料（官方入口）

- LangGraph 持久化与 checkpoint：<https://langchain-ai.github.io/langgraph/concepts/durable_execution/>
- LangGraph 中断与人审：<https://docs.langchain.com/oss/python/langgraph/interrupts>
- PyVISA 文档（USB/GPIB/TCP 等）：<https://pyvisa.readthedocs.io/en/latest/>
- QCoDeS：<https://microsoft.github.io/Qcodes/>
- Bluesky（实验计划/执行生态）：<https://blueskyproject.io/bluesky/>
- NATS JetStream（持久化与至少一次投递）：<https://docs.nats.io/concepts/jetstream>
- OpenAPI：<https://spec.openapis.org/oas/latest.html>

> **版本验证原则**：上述链接仅用于选型和后续研读；具体 SDK API/兼容版本需在项目锁定依赖时重新验证。涉及物理实验的设备协议、安全参数、厂商驱动必须以仪器手册及现场验证结果为准。

---

## 设计总结

项目成功的标准不是“每台仪器都有一个会聊天的 Agent”，而是：**研究人员在 Web 上能审查和控制实验；系统能可靠地把科研意图转成可执行且可追溯的任务；仪器 Agent 可以分享事实、提出建议、完成授权操作；所有真实设备控制都在确定性安全边界内进行。**

推荐先做一个完整的、可交互的**三模拟设备 Web MVP**，验证从“自然语言目标 → 计划 DAG → 审批 → 仪器执行 → 数据共享 → 分析 → 再规划”的闭环，然后再引入真实仪器。
