"""ALAP v3.0 design-contract smoke validation.

Requirements: pip install pyyaml jsonschema
Usage: python contracts/validate_contracts.py
This verifies syntax, JSON Schema, examples and negative input checks, not production safety.
"""
import json
import re
from pathlib import Path
import yaml
from jsonschema import Draft202012Validator, FormatChecker, ValidationError

ROOT = Path(__file__).resolve().parent
schemas = {}
for fp in ROOT.glob("*.schema.json"):
    obj = json.loads(fp.read_text(encoding="utf-8"))
    Draft202012Validator.check_schema(obj)
    schemas[fp.name] = obj

api = yaml.safe_load((ROOT / "openapi.yaml").read_text(encoding="utf-8"))
assert api["openapi"].startswith("3.1")
assert not any("raw-scpi" in path for path in api["paths"])

# Verify all local $ref are resolvable in the OpenAPI document.
def walk_refs(x):
    if isinstance(x, dict):
        for k, v in x.items():
            if k == "$ref":
                assert v.startswith("#/"), f"Unexpected external reference: {v}"
                cur = api
                for part in v[2:].split("/"):
                    cur = cur[part.replace("~1", "/").replace("~0", "~")]
                assert cur is not None
            else:
                walk_refs(v)
    elif isinstance(x, list):
        for item in x:
            walk_refs(item)
walk_refs(api)

valid_samples = {
    "agent_manifest.schema.json": {
        "agent_id": "inst-keithley-01", "version": 1, "kind": "instrument",
        "model_ref": "model-default", "max_iterations": 12,
        "max_runtime_seconds": 180,
        "allowed_tools": ["read_instrument_state", "propose_iv_measurement"],
        "scoped_instruments": ["keithley-01"], "autonomy_level": "L1",
        "skill_refs": ["iv_measurement@1"],
        "context_policy": "experiment_snapshot_only"
    },
    "capability.schema.json": {
        "schema_version": "1.0", "instrument_id": "keithley-01", "gateway_id": "labpc-1",
        "manufacturer": "Keithley", "model": "2450", "driver_version": "1.0", "transport": "gpib",
        "status_ttl_s": 5, "skills": [{"skill_id": "iv_measurement", "version": "1",
        "input_schema_ref": "skills/iv-v1", "safety_class": "operator_review"}],
        "safety_policy_ref": "policy-2450-v1"
    },
    "command.schema.json": {
        "schema_version": "1.0", "command_id": "CMD-001", "experiment_id": "EXP-001",
        "run_id": "RUN-001", "task_id": "TASK-001", "instrument_id": "keithley-01",
        "lease_id": "LEASE-001", "fencing_token": 1, "policy_version": "policy-2450-v1",
        "skill_id": "iv_measurement", "parameters": {"points": 201},
        "deadline_at": "2026-10-16T08:05:00Z", "issued_at": "2026-10-16T08:00:00Z",
        "authorized_plan_hash": "a" * 64, "capability_version": "capability-v1"
    },
    "event.schema.json": {
        "event_id": "87c056bf-a272-4aa1-8e65-e07e901e32c1", "aggregate_id": "EXP-001",
        "aggregate_seq": 43, "event_type": "task.started.v1", "schema_version": "1.0",
        "occurred_at": "2026-10-16T08:00:00Z", "producer": "experiment-engine",
        "trace_id": "trace-001", "experiment_id": "EXP-001",
        "payload": {"task_id": "TASK-001"}
    },
    "plan_proposal.schema.json": {
        "proposal_id": "P-001", "experiment_id": "EXP-001",
        "source_agent_run_id": "AR-001", "based_on_snapshot_version": 1,
        "requested_resources": ["keithley-01"],
        "tasks": [{"id": "t1", "kind": "measure_iv", "resource_id": "keithley-01",
                   "parameters": {"points": 201}}],
        "reason": "Validate IV response"
    },
    "dataset_manifest.schema.json": {
        "dataset_id": "DATA-001", "experiment_id": "EXP-001", "run_id": "RUN-001",
        "task_id": "TASK-001", "instrument_ids": ["keithley-01"],
        "acquisition_interval": {"start_utc": "2026-10-16T08:00:00Z",
                                 "end_utc": "2026-10-16T08:00:20Z"},
        "data_format": "hdf5", "storage_uri": "datasets/EXP-001/DATA-001.h5",
        "checksum_sha256": "c" * 64, "unit_map": {"current": "A", "voltage": "V"},
        "status": "COMMITTED"
    }
}

for name, value in valid_samples.items():
    Draft202012Validator(schemas[name], format_checker=FormatChecker()).validate(value)

# Negative tests: reject invalid physical command, unsupported agent level,
# malformed event type, and missing acquisition provenance.
negative_samples = [
    ("command.schema.json", {**valid_samples["command.schema.json"], "fencing_token": -1}),
    ("agent_manifest.schema.json", {**valid_samples["agent_manifest.schema.json"], "autonomy_level": "L99"}),
    ("event.schema.json", {**valid_samples["event.schema.json"], "event_type": "unsafe raw write"}),
    ("dataset_manifest.schema.json", {k: v for k, v in valid_samples["dataset_manifest.schema.json"].items() if k != "task_id"}),
]
for name, invalid in negative_samples:
    try:
        Draft202012Validator(schemas[name], format_checker=FormatChecker()).validate(invalid)
    except ValidationError:
        pass
    else:
        raise AssertionError(f"Negative sample unexpectedly accepted by {name}")

print(f"PASS: OpenAPI YAML and local refs, {len(schemas)} JSON Schemas, "
      f"{len(valid_samples)} valid samples, {len(negative_samples)} negative checks")
