# ALAP 契约目录

契约仍是**设计草案**；并非已经运行的 Web API 或仪器控制服务。

- `openapi.yaml`：浏览器/应用服务 REST + SSE API 的初步机器可读契约。
- `agent_manifest.schema.json`：Agent 配置的模型、权限和工具边界。
- `plan_proposal.schema.json`：多 Agent 生成候选计划的输入结构。
- `capability.schema.json`：仪器能力清单与驱动/策略版本。
- `command.schema.json`：Gateway 高层命令信封；不意味着 Schema 校验即可授权。
- `event.schema.json`：异步事件 envelope（内部事件也需授权消费）。
- `dataset_manifest.schema.json`：科学数据的采集区间、单位、哈希与来源。

运行 `python contracts/validate_contracts.py`（需要 `pyyaml`、`jsonschema`）验证 YAML、全部本地 OpenAPI `$ref`、全部 JSON Schema、正例与反例。

**Schema 只保证报文形状**：需要在代码中另行检查计划 DAG 无环、命令截止时间晚于签发时间、实际单位换算/限幅、审批绑定、设备真实状态及命令身份。生产阶段还应采用数据库迁移/双向契约测试及契约破坏性变更审批。
