# ALAP Engineering Design v3.0

**Autonomous Laboratory Agent Platform · 分布式多智能体自主实验平台**

| 元数据 | 值 |
|---|---|
| 版本 | v3.0 · 工程设计基线（Draft / 待评审） |
| 日期 | 2026-10-16 |
| 系统范围 | Web 平台、Agent Platform、Experiment Execution Platform、边缘 Gateway、实验数据与设备安全 |
| 上一版本 | [`legacy/ARCHITECTURE_v2.0.md`](legacy/ARCHITECTURE_v2.0.md) |
| 当前状态 | **设计稿而非可运行产品、设备手册或经认证的安全方案** |

## 0. 核心结论

**Agent Platform 负责生成候选决策；Experiment Execution Platform 负责裁决及可靠执行；Gateway 负责近端受约束的设备操作。** 物理互锁、急停及厂商定义的故障处理必须独立于 LLM/Web 服务。采用“实验级集中仲裁 + 仪器级有限自治 + 边缘确定性执行”。

用户现有仪器通过 TCP、GPIB、USB 或已有透明/半透明桥接程序接入；新系统先兼容旧桥接，在上层增加类型化能力描述、设备锁、命令结果核对及审计，而不是直接重写所有驱动。

## 1. 文档地图与阅读顺序

| 编号 | 文档 | 主要回答的问题 | 开发依赖 |
|---|---|---|---|
| 01 | [`docs/01_PRD.md`](docs/01_PRD.md) | 谁用、解决什么问题、Web 产品边界 | 基线 |
| 02 | [`docs/02_SRS.md`](docs/02_SRS.md) | 哪些需求可测、何时验收 | 基线 |
| 03 | [`docs/03_ARCHITECTURE.md`](docs/03_ARCHITECTURE.md) | 系统如何分层与部署、谁是状态权威 | 基线 |
| 04 | [`docs/04_WEB_UX.md`](docs/04_WEB_UX.md) | 页面、组件、用户交互及断线行为 | Web |
| 05 | [`docs/05_AGENT_PLATFORM.md`](docs/05_AGENT_PLATFORM.md) | Agent Runtime、工具、技能、上下文如何工作 | Agent |
| 06 | [`docs/06_MULTI_AGENT.md`](docs/06_MULTI_AGENT.md) | Planner、设备 Agent 如何协商与仲裁 | Agent/调度 |
| 07 | [`docs/07_EXPERIMENT_ENGINE.md`](docs/07_EXPERIMENT_ENGINE.md) | DAG、资源锁、物理操作如何安全执行与恢复 | 调度 |
| 08 | [`docs/08_GATEWAY.md`](docs/08_GATEWAY.md) | TCP/GPIB/USB/桥接程序如何标准化接入 | 边缘 |
| 09 | [`docs/09_DATA_EVENTS.md`](docs/09_DATA_EVENTS.md) | 状态、事件、实验数据、血缘如何存储 | 数据 |
| 10 | [`docs/10_API_PROTOCOLS.md`](docs/10_API_PROTOCOLS.md) | REST、SSE、命令与事件的契约 | 全栈 |
| 11 | [`docs/11_SAFETY_SECURITY.md`](docs/11_SAFETY_SECURITY.md) | 硬件安全、风险、权限、Prompt Injection | 上线门禁 |
| 12 | [`docs/12_EVALUATION.md`](docs/12_EVALUATION.md) | 模拟环境、Agent 评测、故障注入和验收 | QA |
| 13 | [`docs/13_DEPLOYMENT.md`](docs/13_DEPLOYMENT.md) | 部署、监控、备份、升级与灾备 | 运维 |
| 14 | [`docs/14_ROADMAP.md`](docs/14_ROADMAP.md) | 依赖、迭代任务、里程碑、Definition of Done | 实施 |
| 15 | [`docs/15_ADR.md`](docs/15_ADR.md) | 已作的决策、开放问题及取舍 | 维护 |
| 16 | [`docs/16_TRACEABILITY.md`](docs/16_TRACEABILITY.md) | 需求 → 设计 → API → 测试 的映射 | 质量 |

**机器可读契约**：[`contracts/openapi.yaml`](contracts/openapi.yaml)、[`contracts/agent_manifest.schema.json`](contracts/agent_manifest.schema.json)、[`contracts/capability.schema.json`](contracts/capability.schema.json)、[`contracts/event.schema.json`](contracts/event.schema.json)、[`contracts/command.schema.json`](contracts/command.schema.json)、[`contracts/plan_proposal.schema.json`](contracts/plan_proposal.schema.json)、[`contracts/dataset_manifest.schema.json`](contracts/dataset_manifest.schema.json)。

## 2. 文档地位与实施原则

- **MUST / 必须**：进入真实设备控制前不可省略；**SHOULD / 应**：优先实现，偏离需记录 ADR；**MAY / 可**：增强能力。
- 任何电流、电压、磁场、温度、变化速率的例子均为**非授权示例**，不得据此直接控制设备。真实限值须由设备手册、线缆/样品条件及负责人共同确定。
- 本设计的延迟、成功率、RPO/RTO 等指标若出现“建议阈值”，仅代表**候选验收门槛**，必须经现场基准测试定稿。
- 不作“完全自主无人值守”“消息 exactly-once 等于物理动作 exactly-once”“LLM 判断设备已安全”等承诺。
- 本版偏向 **模块化单体后端 + 独立 Agent Worker + 独立边缘 Gateway**；只有获得真实负载数据后才拆成更多微服务。

## 3. 推荐最小闭环

1. 用户在 Web 创建实验，选择三台**模拟**仪器与样品，并输入目标。
2. Planner 产生 `PlanProposal`；用户查看结构化计划并批准。
3. Scheduler 检查 DAG、依赖、权限、资源锁及已批准的约束。
4. Gateway Simulator 本地执行（不使用 LLM 控制逐点扫描）；事件通过 Outbox→NATS 分发。
5. 采集结果写入数据存储，数据库保留版本、时间戳、哈希和来源。
6. Agent 分析后仅能提交新的 `Proposal`，不能直接改变别的设备。
7. Web 可观察、暂停、取消、审查执行轨迹，并在重连后补齐事件。

真实设备接入须完成 **11_SAFETY_SECURITY + 12_EVALUATION** 的专项门禁。

## 4. 未定项（不能假定）

仪器型号与控制协议、现有桥接程序功能、最大并发实验数、物理紧急停止与磁体失联策略、实验室网络分段、样品参数许可范围、用户体系和数据保留期仍需现场调查；在确认前，所有相关设计为接口级抽象。

## 5. 使用本包

- 从本目录打开 Markdown；Mermaid 可在支持该语法的编辑器渲染。
- 后端开发首先审阅 `contracts/`，把 OpenAPI / JSON Schema 作为 CI 契约测试输入。
- 产品与前端团队先审 `04_WEB_UX` 的用户旅程与状态表。
- 仪器负责人审查 `08_GATEWAY`、`11_SAFETY_SECURITY`，签署真实设备门禁。
- `legacy/` 原样保留 v2 供对照；**v3 文档优先于 v2**，若发生矛盾需登记 ADR。

## 6. 官方参考资料（可变动）

- LangGraph Persistence：<https://docs.langchain.com/oss/python/langgraph/persistence>
- LangGraph Interrupts：<https://docs.langchain.com/oss/python/langgraph/interrupts>
- NATS JetStream：<https://docs.nats.io/concepts/jetstream>
- QCoDeS：<https://microsoft.github.io/Qcodes/>
- PyVISA：<https://pyvisa.readthedocs.io/>
- OWASP LLM Prompt Injection Cheat Sheet：<https://cheatsheetseries.owasp.org/cheatsheets/LLM_Prompt_Injection_Prevention_Cheat_Sheet.html>
- NIST AI RMF：<https://airc.nist.gov/>

说明：参考链接用于框架事实与安全实践，**本项目的边界、接口、状态机为建议设计，并非上述项目提供的现成系统**。
